const express=require("express")
const router=express.Router()
const auth=require("../controllers/authController")

router.post("/signup",auth.signup)
router.post("/signin",auth.login)
router.get("/verify",auth.verify)

module.exports=router