const mongoose=require("mongoose")
const Schema=mongoose.Schema
const RoleSchema=new Schema({
    username:{
        type:String,
        required:true
    },
    password:{
        type:String,
        required:true
    },
    role:{
        type:String,
        required:true
    }
})

const Role = mongoose.model("Role",RoleSchema,"role")
module.exports=Role