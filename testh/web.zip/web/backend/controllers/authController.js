const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const Role=require("../models/Role")

const signup = async (req, res) => {
    const { username, password, role } = req.body;
    await Role.findOne({ username: username })
      .then((response) => {
        if (response) {
          res.status(409).json({
            message: "User already exists",
          });
        } else {
          bcrypt.hash(password, 10).then((hash) => {
            const user = new Role({
              username: username,
              password: hash,
              role: role,
            });
            user
              .save()
              .then((response) => {
                res.status(201).json({
                  status: "success",
                  message: "User created successfully",
                  response,
                });
              })
              .catch((err) => {
                console.log(err);
                res.status(500).json({
                  message: "Error in creating user",
                });
              });
          });
        }
      })
      .catch((err) => res.json(err));
  };
  
  const login = async (req, res) => {
    const { username, password } = req.body;
    await Role.findOne({ username: username })
      .then((response) => {
        if (!response) {
          res.json({
            message: "User not found",
          });
        } else {
          const isMatch = bcrypt.compareSync(password, response.password);
          if (!isMatch) {
            res.json({
              message: "Invalid Credentials",
            });
          } else {
            const token = jwt.sign(
              {
                _id: response._id,
              },
              process.env.JWT_SECRET,
              {
                expiresIn: "2d",
              }
            );
            const refreshToken = jwt.sign(
              {
                _id: response._id,
              },
              process.env.JWT_SECRET,
              {
                expiresIn: "5d",
              }
            );
            Role.findOne({ username: response.username }).then((user) => {
              user.refreshToken = refreshToken;
              user.save().then(() =>
                res.json({
                  status: "success",
                  role: response.role,
                  token: token,
                })
              );
            });
          }
        }
      })
      .catch((err) => res.json(err));
  }
  
  const updateUser = async (req, res) => {
    const updateUser = req.body;
    const userDetails = req.userDetails;
    await Role.findByIdAndUpdate(userDetails._id, updateUser)
      .then(() => {
        res.json("user updated successfully");
      })
      .catch((err) => res.json(err));
  };
  
  const verify = async (req, res, next) => {
    const jwttoken = req.headers["authorization"];
    const token = jwttoken;
    if (!token) {
      return res.status(401).json({ message: "No token provided" });
    }
    try {
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      req.userDetails = decoded;
      next();
    } catch (err) {
      return res.status(401).json({ message: "Invalid token" });
    }
  };
  
  module.exports = {
    signup,
    login,
    verify,
    updateUser,
  };